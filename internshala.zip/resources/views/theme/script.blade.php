<script src="{!! asset('assets/plugins/common/common.min.js') !!}"></script>
<script src="{!! asset('assets/js/custom.min.js') !!}"></script>
<script src="{!! asset('assets/js/settings.js') !!}"></script>
<script src="{!! asset('assets/js/gleek.js') !!}"></script>
<script src="{!! asset('assets/js/styleSwitcher.js') !!}"></script>

<!-- Circle progress -->
<script src="{!! asset('assets/plugins/circle-progress/circle-progress.min.js') !!}"></script>
<!-- Datamap -->
<script src="{!! asset('assets/plugins/d3v3/index.js') !!}"></script>
<script src="{!! asset('assets/plugins/topojson/topojson.min.js') !!}"></script>
<!-- Morrisjs -->
<script src="{!! asset('assets/plugins/raphael/raphael.min.js') !!}"></script>
<script src="{!! asset('assets/plugins/morris/morris.min.js') !!}"></script>
<!-- Pignose Calender -->
<script src="{!! asset('assets/plugins/moment/moment.min.js') !!}"></script>
<script src="{!! asset('assets/plugins/pg-calendar/js/pignose.calendar.min.js') !!}"></script>
<!-- ChartistJS -->
<script src="{!! asset('assets/plugins/chartist/js/chartist.min.js') !!}"></script>
<script src="{!! asset('assets/plugins/chartist-plugin-tooltips/js/chartist-plugin-tooltip.min.js') !!}"></script>

<script src="{!! asset('assets/plugins/sweetalert/js/sweetalert.min.js') !!}"></script>
<script src="{!! asset('assets/plugins/sweetalert/js/sweetalert.init.js') !!}"></script>

<script src="{!! asset('assets/plugins/tables/js/jquery.dataTables.min.js') !!}"></script>
<script src="{!! asset('assets/plugins/tables/js/datatable/dataTables.bootstrap4.min.js') !!}"></script>
<script src="{!! asset('assets/plugins/tables/js/datatable-init/datatable-basic.min.js') !!}"></script>
@yield('script')
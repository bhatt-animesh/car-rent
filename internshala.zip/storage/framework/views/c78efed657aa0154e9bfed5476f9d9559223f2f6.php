<table class="table table-striped table-bordered zero-configuration">
    <thead>
        <tr>
            <th>Vehicle Model</th>
            <th>Vehicle Number</th>
            <th>Seating Capacity</th>
            <th>Rent Per Day</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="dataid<?php echo e($car->id); ?>">
            <td><?php echo e($car->vehicle_model); ?></td>
            <td><?php echo e($car->vehicle_number); ?></td>
            <td><?php echo e($car->seating_capacity); ?></td>
            <td><?php echo e($car->rent); ?> Rs.</td>
            <td>
                <a href="<?php echo e(URL::to('/customer/car/booking/')); ?>/<?php echo e($car->id); ?>" data-toggle="tooltip" data-placement="top" title="Book Now" data-original-title="Book Now">
                    <span class="badge badge-info">BookNow</span>
                </a>
            </td>           
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\Users\anime\Desktop\internshala\resources\views/customer_tables/cars.blade.php ENDPATH**/ ?>
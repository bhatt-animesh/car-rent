<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name')); ?></title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo asset('images/fav.jpg'); ?>">
    <!-- Pignose Calender -->
    <link href="<?php echo asset('assets/plugins/pg-calendar/css/pignose.calendar.min.css'); ?>" rel="stylesheet">
    <!-- Chartist -->
    <link rel="stylesheet" href="<?php echo asset('assets/plugins/chartist/css/chartist.min.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('assets/plugins/chartist-plugin-tooltips/css/chartist-plugin-tooltip.css'); ?>">

    <link href="<?php echo asset('assets/plugins/tables/css/datatable/dataTables.bootstrap4.min.css'); ?>" rel="stylesheet">
    <!-- Custom Stylesheet -->
    <link href="<?php echo asset('assets/plugins/sweetalert/css/sweetalert.css'); ?>" rel="stylesheet">
    <link href="<?php echo asset('assets/css/style.css'); ?>" rel="stylesheet">

</head>
<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="loader">
            <svg class="circular" viewBox="25 25 50 50">
                <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="3" stroke-miterlimit="10" />
            </svg>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    <div id="main-wrapper">

        <?php echo $__env->make('theme.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('theme.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="content-body">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
    <!-- /#wrapper -->

    <?php echo $__env->make('theme.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
</body>

</html><?php /**PATH C:\Users\anime\Desktop\internshala\resources\views/theme/default.blade.php ENDPATH**/ ?>
<table class="table table-striped table-bordered zero-configuration">
    <thead>
        <tr>
            <th>Booked By</th>
            <th>Vehicle Model</th>
            <th>Number Of Day</th>
            <th>Date Of Booking</th>
            <th>Total Payable Amount</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $cars_bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="dataid<?php echo e($book->id); ?>">
            <td><?php echo e($book['user_details']->name); ?></td>
            <td><?php echo e($book['car_details']->vehicle_model); ?></td>
            <td><?php echo e($book->number_of_day); ?></td>
            <td><?php echo e($book->date_of_booking); ?></td>
            <td><?php echo e($book->number_of_day * $book['car_details']->rent); ?> Rs.</td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\Users\anime\Desktop\internshala\resources\views/agency_tables/cars-booking.blade.php ENDPATH**/ ?>
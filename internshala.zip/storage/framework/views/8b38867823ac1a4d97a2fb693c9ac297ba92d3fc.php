

<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-3">
        <div class="row">
            <div class="col-lg-3 col-sm-6">
                <div class="card gradient-3">
                <a href="#" aria-expanded="false">
                    <div class="card-body">
                        <h3 class="card-title text-white">Cars Available To Book</h3>
                        <div class="d-inline-block">
                            <h2 class="text-white"><?php echo e(count($cars)); ?></h2>
                        </div>
                        <span class="float-right display-5 opacity-5"><i class="fa fa-car"></i></span>
                    </div>
                    </a>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="card gradient-2">
                <a href="<?php echo e(URL::to('/customer/mybooking')); ?>" aria-expanded="false">
                    <div class="card-body">
                        <h3 class="card-title text-white">My Booking</h3>
                        <div class="d-inline-block">
                            <h2 class="text-white"><?php echo e(count($cars_bookings)); ?></h2>
                        </div>
                        <span class="float-right display-5 opacity-5"><i class="fa fa-calendar-o"></i></span>
                    </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!-- #/ container -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <span id="message"></span>
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Cars Available To Book</h4>
                        <div class="table-responsive" id="table-display">
                            <?php echo $__env->make('customer_tables.cars', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\anime\Desktop\internshala\resources\views/customer/index.blade.php ENDPATH**/ ?>
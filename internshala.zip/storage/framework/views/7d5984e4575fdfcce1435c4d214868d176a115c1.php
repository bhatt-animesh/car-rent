<table class="table table-striped table-bordered zero-configuration">
    <thead>
        <tr>
            <th>Status</th>
            <th>Vehicle Model</th>
            <th>Vehicle Number</th>
            <th>Number Of Day</th>
            <th>Date Of Booking</th>
            <th>Total Payable Amount</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $mybookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="dataid<?php echo e($book->id); ?>">
            <td><span class="badge badge-success">Booked</span></td>
            <td><?php echo e($book['car_details']->vehicle_model); ?></td>
            <td><?php echo e($book['car_details']->vehicle_number); ?></td>
            <td><?php echo e($book->number_of_day); ?></td>
            <td><?php echo e($book->date_of_booking); ?></td>
            <td><?php echo e($book->number_of_day * $book['car_details']->rent); ?> Rs.</td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\Users\anime\Desktop\internshala\resources\views/customer_tables/my-booking.blade.php ENDPATH**/ ?>